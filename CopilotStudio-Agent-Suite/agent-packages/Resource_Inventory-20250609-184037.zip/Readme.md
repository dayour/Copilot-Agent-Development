# Resource Inventory

A specialized conversational agent built with Microsoft Copilot Studio focused on comprehensive IT asset and resource inventory management. This agent assists IT operations teams in tracking, cataloging, and managing resources across cloud and on-premises environments.

## Purpose

The Resource Inventory agent is designed to help IT operations teams with:

- **Asset Discovery**: Automated resource discovery and cataloging
- **Inventory Management**: Comprehensive asset tracking and lifecycle management
- **Compliance Reporting**: Audit preparation and compliance tracking
- **Optimization**: Resource utilization and cost optimization
- **Documentation**: Asset documentation and change management
- **Analytics**: Inventory insights and reporting

## Key Capabilities

### 🔍 Discovery & Cataloging
- Automated resource discovery across environments
- Asset classification and tagging
- Inventory data collection and validation

### 📋 Lifecycle Management
- Asset lifecycle tracking from procurement to retirement
- Change management and version control
- Maintenance scheduling and tracking

### 📊 Reporting & Analytics
- Comprehensive inventory reporting
- Utilization analysis and optimization recommendations
- Compliance and audit reporting

### 🔧 Automation
- Automated inventory updates
- Integration with discovery tools
- Workflow automation for asset management

### 🏷️ Asset Management

- Asset tagging and categorization
- Resource classification and organization
- Inventory report generation and distribution
- Asset lifecycle documentation and tracking

## Specialized Topics Coverage

This agent includes dedicated topics for:

- **Asset Discovery**: Automated resource scanning and discovery processes
- **Inventory Tracking**: Comprehensive asset lifecycle and change management
- **Compliance Reporting**: Audit-ready reports and compliance verification
- **Asset Tagging**: Resource categorization and organizational management

## Conversation Starters

The agent provides guided entry points for inventory management:

- **Asset Discovery**: Automated resource discovery and cataloging
- **Inventory Updates**: Asset tracking and lifecycle management
- **Compliance Checks**: Audit preparation and regulatory compliance
- **Optimization Analysis**: Resource utilization and cost optimization

## Technical Configuration

- **Authentication Mode**: Integrated
- **Access Control**: ChatbotReaders
- **AI Capabilities**: GPT-enabled with web browsing
- **Schema**: cre44_resourceInventory
- **Recognition**: GenerativeAI-based intent recognition

## Integration Points

- **Azure Resource Graph**: For cloud resource discovery
- **System Center Configuration Manager**: For on-premises inventory
- **Microsoft Intune**: For device management
- **ServiceNow/Other ITSM**: For asset management integration

---

*Built on the Darbot template framework for consistent agent architecture and maintainability.*
