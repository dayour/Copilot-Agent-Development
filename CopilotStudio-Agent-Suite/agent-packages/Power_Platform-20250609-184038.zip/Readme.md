# Power Platform

A specialized conversational agent built with Microsoft Copilot Studio focused on Power Platform administration, development, and governance. This agent assists administrators and developers in comprehensive Power Platform management.

## Purpose

The Power Platform agent is designed to help Power Platform teams with:

- **Platform Administration**: Environment and tenant management
- **Development Support**: Power Apps, Power Automate, and Power BI development
- **Governance**: Center of Excellence and governance implementation
- **Integration**: Cross-platform integration and connectivity
- **Security**: Platform security and access management
- **Optimization**: Performance optimization and best practices

## Key Capabilities

### 🏗️ Platform Management
- Environment lifecycle management
- Tenant configuration and administration
- Capacity planning and management

### 💻 Development Support
- Power Apps development guidance
- Power Automate workflow design
- Power BI analytics and reporting
- Power Virtual Agents creation

### 🏛️ Governance & COE
- Center of Excellence implementation
- Governance policies and standards
- Compliance and security management

### 🔗 Integration & Connectivity
- Connector management and custom connectors
- External system integration
- API management and security

### 🔧 Environment Management

- Environment provisioning and configuration
- Governance enforcement and policy implementation
- Capacity monitoring and optimization
- Performance tuning and troubleshooting

## Specialized Topics Coverage

This agent includes dedicated topics for:

- **App Development**: Power Apps application design and development guidance
- **Flow Automation**: Power Automate workflow creation and optimization
- **Platform Governance**: COE implementation and governance policy management
- **Environment Provisioning**: Environment lifecycle and configuration management
- **Governance Enforcement**: Policy implementation and compliance monitoring

## Conversation Starters

The agent provides guided entry points for Power Platform management:

- **App Development**: Power Apps development best practices and guidance
- **Workflow Automation**: Power Automate flow design and optimization
- **Platform Administration**: Environment and tenant management
- **Governance Implementation**: COE setup and policy enforcement

## Technical Configuration

- **Authentication Mode**: Integrated
- **Access Control**: ChatbotReaders
- **AI Capabilities**: GPT-enabled with web browsing
- **Schema**: cre44_powerPlatform
- **Recognition**: GenerativeAI-based intent recognition

## Integration Points

- **Power Platform Admin Center**: For platform administration
- **Microsoft Dataverse**: For data platform integration
- **Azure Active Directory**: For identity and access management
- **Microsoft 365**: For productivity integration

---

*Built on the Darbot template framework for consistent agent architecture and maintainability.*
