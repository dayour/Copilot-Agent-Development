# Agent Installation Script for Entra_Security_Manager
Write-Host "Installing agent: Entra_Security_Manager"

# Verify required files
$RequiredFiles = @(
    "agent.mcs.yml",
    "settings.mcs.yml",
    "Readme.md", 
    "icon.png"
)

foreach ($File in $RequiredFiles) {
    if (!(Test-Path $File)) {
        Write-Error "Missing required file: $File"
        exit 1
    }
}

Write-Host "✅ Agent package validated successfully"
Write-Host "📖 Please refer to Readme.md for manual import instructions"
